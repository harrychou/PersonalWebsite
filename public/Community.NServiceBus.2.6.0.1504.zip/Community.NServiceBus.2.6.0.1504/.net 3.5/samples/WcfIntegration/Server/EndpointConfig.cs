﻿using NServiceBus;

namespace Server
{
    internal class EndpointConfig : IConfigureThisEndpoint, AsA_Publisher
    {
    }
}