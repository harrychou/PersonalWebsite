﻿using NServiceBus;

namespace Subscriber1
{
    class EndpointConfig : IConfigureThisEndpoint, AsA_Server {}
}
