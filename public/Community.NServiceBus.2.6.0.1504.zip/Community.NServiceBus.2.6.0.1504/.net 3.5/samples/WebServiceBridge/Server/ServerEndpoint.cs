using NServiceBus;

namespace Server
{
    public class ServerEndpoint :   IConfigureThisEndpoint, AsA_Server { }
}