using NServiceBus;

namespace MyClient
{
    public class EndpointConfig : IConfigureThisEndpoint, AsA_Client {}
}