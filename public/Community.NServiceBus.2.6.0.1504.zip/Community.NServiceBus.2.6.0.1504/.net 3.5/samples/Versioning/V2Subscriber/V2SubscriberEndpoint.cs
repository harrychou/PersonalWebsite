using NServiceBus;

namespace V2Subscriber
{
    public class V2SubscriberEndpoint : IConfigureThisEndpoint, AsA_Server { }
}