using NServiceBus;

namespace Server
{
    public class MessageEndpoint :  IConfigureThisEndpoint, AsA_Server
    {
    }

}