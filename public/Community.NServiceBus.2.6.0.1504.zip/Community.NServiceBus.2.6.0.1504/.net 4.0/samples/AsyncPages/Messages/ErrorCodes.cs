namespace Messages
{
    public enum ErrorCodes
    {
        None,
        Fail
    }
}
