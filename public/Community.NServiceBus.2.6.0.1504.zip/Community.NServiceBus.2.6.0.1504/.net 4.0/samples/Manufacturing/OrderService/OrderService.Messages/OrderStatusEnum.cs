namespace OrderService.Messages
{
    public enum OrderStatusEnum
    {
        Tentative,
        Recieved,
        Authorized,
        Rejected,
        Accepted
    }
}
