﻿using NServiceBus;

namespace V2Publisher
{
    class EndpointConfig : IConfigureThisEndpoint, AsA_Publisher { }
}
