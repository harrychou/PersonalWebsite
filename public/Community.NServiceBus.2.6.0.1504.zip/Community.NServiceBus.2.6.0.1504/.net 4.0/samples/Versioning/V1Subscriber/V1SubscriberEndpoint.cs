using NServiceBus;

namespace V1Subscriber
{
    public class V1SubscriberEndpoint : IConfigureThisEndpoint, AsA_Server { }
}